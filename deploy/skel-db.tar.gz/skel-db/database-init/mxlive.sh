#!/bin/bash
set -e

psql -v ON_ERROR_STOP=1 --username "$POSTGRES_USER" <<-EOSQL
    CREATE USER mxlive WITH PASSWORD 'iSY67mb0oVYg64wkKKZ7YLvPISGmhLkT';
    CREATE DATABASE mxlive;
    GRANT ALL PRIVILEGES ON DATABASE mxlive TO mxlive;
EOSQL

