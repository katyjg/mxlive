# LDAP
LDAP_BASE_DN        = "dc=example,dc=com"
LDAP_ADMIN_UIDS      = [1000]
LDAP_MANAGER_CN     = "cn=Directory Manager"
LDAP_MANAGER_SECRET = "secret"
LDAP_USER_ROOT      = "/home"
LDAP_SEND_EMAILS    = True
AUTH_LDAP_SERVER_URI = 'ldap://ldap.example.com'

INTERNAL_IPS = [
    '0.0.0.0/0',
]

DEBUG = True
DOWNLOAD_CACHE_DIR = "/mxlive/local/cache"


IMAGE_PREPEND = ''

DATABASES = {
    'default': {
	    'ENGINE': 'django.db.backends.mysql',
	    'NAME': 'mxlive',
	    'USER': 'root',
	    'PASSWORD': '',
	    'HOST': 'db.example.com',
	    'PORT': ''
    },
}

ADMINS = [
    ('Admin','admin@example.com'),
]
MANAGERS = [
    ('Manager','Manager@example.com'),
]

EMAIL_SUBJECT_PREFIX = '[MxLIVE] '

TIME_ZONE = "America/Regina"

EMAIL_HOST_USER = "system@mail.example.com"
EMAIL_HOST_PASSWORD = "secret"
EMAIL_PORT = 25
EMAIL_HOST = "mail.example.com"

#
# Uncomment the follwing two lines to enable trusting self-signed certificates
#

#import ssl
#ssl._create_default_https_context = ssl._create_unverified_context
